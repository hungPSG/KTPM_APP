﻿
namespace KTPM_APP
{
    partial class MainQL
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainQL));
            this.panelMenu = new System.Windows.Forms.Panel();
            this.buttonTaiChinh = new System.Windows.Forms.Button();
            this.buttonCorona = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.buttonHome = new System.Windows.Forms.Button();
            this.buttonLuong = new System.Windows.Forms.Button();
            this.buttonNV = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBoxExit = new System.Windows.Forms.PictureBox();
            this.pictureSize = new System.Windows.Forms.PictureBox();
            this.panelConten = new System.Windows.Forms.Panel();
            this.panelMenu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxExit)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureSize)).BeginInit();
            this.SuspendLayout();
            // 
            // panelMenu
            // 
            this.panelMenu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(163)))), ((int)(((byte)(255)))));
            this.panelMenu.Controls.Add(this.buttonTaiChinh);
            this.panelMenu.Controls.Add(this.buttonCorona);
            this.panelMenu.Controls.Add(this.label4);
            this.panelMenu.Controls.Add(this.label3);
            this.panelMenu.Controls.Add(this.label2);
            this.panelMenu.Controls.Add(this.pictureBox1);
            this.panelMenu.Controls.Add(this.label1);
            this.panelMenu.Controls.Add(this.buttonHome);
            this.panelMenu.Controls.Add(this.buttonLuong);
            this.panelMenu.Controls.Add(this.buttonNV);
            this.panelMenu.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelMenu.Location = new System.Drawing.Point(0, 0);
            this.panelMenu.Name = "panelMenu";
            this.panelMenu.Size = new System.Drawing.Size(250, 650);
            this.panelMenu.TabIndex = 0;
            this.panelMenu.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panelConten_MouseDown);
            // 
            // buttonTaiChinh
            // 
            this.buttonTaiChinh.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonTaiChinh.FlatAppearance.BorderSize = 0;
            this.buttonTaiChinh.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.buttonTaiChinh.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonTaiChinh.Font = new System.Drawing.Font("#9Slide01 Tieu de ngan", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.buttonTaiChinh.Image = ((System.Drawing.Image)(resources.GetObject("buttonTaiChinh.Image")));
            this.buttonTaiChinh.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonTaiChinh.Location = new System.Drawing.Point(0, 341);
            this.buttonTaiChinh.Name = "buttonTaiChinh";
            this.buttonTaiChinh.Size = new System.Drawing.Size(250, 40);
            this.buttonTaiChinh.TabIndex = 4;
            this.buttonTaiChinh.Text = "     Tài Chính";
            this.buttonTaiChinh.UseVisualStyleBackColor = true;
            // 
            // buttonCorona
            // 
            this.buttonCorona.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonCorona.FlatAppearance.BorderSize = 0;
            this.buttonCorona.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.buttonCorona.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonCorona.Font = new System.Drawing.Font("#9Slide01 Tieu de ngan", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.buttonCorona.Image = ((System.Drawing.Image)(resources.GetObject("buttonCorona.Image")));
            this.buttonCorona.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonCorona.Location = new System.Drawing.Point(0, 387);
            this.buttonCorona.Name = "buttonCorona";
            this.buttonCorona.Size = new System.Drawing.Size(250, 40);
            this.buttonCorona.TabIndex = 3;
            this.buttonCorona.Text = "     Covid-19";
            this.buttonCorona.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(76, 596);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(166, 20);
            this.label4.TabIndex = 4;
            this.label4.Text = "156system@gmail.com ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(76, 575);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(89, 20);
            this.label3.TabIndex = 3;
            this.label3.Text = "0123456789";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(76, 551);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(77, 20);
            this.label2.TabIndex = 2;
            this.label2.Text = "156 Team ";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(0, 548);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(70, 70);
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("#9Slide01 Tieu de ngan", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(6, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(237, 25);
            this.label1.TabIndex = 2;
            this.label1.Text = "Employee management";
            // 
            // buttonHome
            // 
            this.buttonHome.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonHome.FlatAppearance.BorderSize = 0;
            this.buttonHome.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.buttonHome.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonHome.Font = new System.Drawing.Font("#9Slide01 Tieu de ngan", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.buttonHome.Image = ((System.Drawing.Image)(resources.GetObject("buttonHome.Image")));
            this.buttonHome.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonHome.Location = new System.Drawing.Point(0, 194);
            this.buttonHome.Name = "buttonHome";
            this.buttonHome.Size = new System.Drawing.Size(250, 40);
            this.buttonHome.TabIndex = 2;
            this.buttonHome.Text = "       Home";
            this.buttonHome.UseVisualStyleBackColor = true;
            this.buttonHome.Click += new System.EventHandler(this.button3_Click);
            // 
            // buttonLuong
            // 
            this.buttonLuong.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonLuong.FlatAppearance.BorderSize = 0;
            this.buttonLuong.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.buttonLuong.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonLuong.Font = new System.Drawing.Font("#9Slide01 Tieu de ngan", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.buttonLuong.Image = ((System.Drawing.Image)(resources.GetObject("buttonLuong.Image")));
            this.buttonLuong.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonLuong.Location = new System.Drawing.Point(0, 286);
            this.buttonLuong.Name = "buttonLuong";
            this.buttonLuong.Size = new System.Drawing.Size(250, 40);
            this.buttonLuong.TabIndex = 2;
            this.buttonLuong.Text = "        Lương Thưởng";
            this.buttonLuong.UseVisualStyleBackColor = true;
            // 
            // buttonNV
            // 
            this.buttonNV.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonNV.FlatAppearance.BorderSize = 0;
            this.buttonNV.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.buttonNV.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonNV.Font = new System.Drawing.Font("#9Slide01 Tieu de ngan", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.buttonNV.Image = ((System.Drawing.Image)(resources.GetObject("buttonNV.Image")));
            this.buttonNV.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonNV.Location = new System.Drawing.Point(0, 240);
            this.buttonNV.Name = "buttonNV";
            this.buttonNV.Size = new System.Drawing.Size(250, 40);
            this.buttonNV.TabIndex = 0;
            this.buttonNV.Text = "       Nhân Viên";
            this.buttonNV.UseVisualStyleBackColor = true;
            this.buttonNV.Click += new System.EventHandler(this.buttonNV_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.WhiteSmoke;
            this.panel1.Controls.Add(this.pictureBox2);
            this.panel1.Controls.Add(this.pictureBoxExit);
            this.panel1.Controls.Add(this.pictureSize);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(250, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1050, 50);
            this.panel1.TabIndex = 1;
            this.panel1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panelConten_MouseDown);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(962, 9);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(35, 35);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 2;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // pictureBoxExit
            // 
            this.pictureBoxExit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBoxExit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBoxExit.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxExit.Image")));
            this.pictureBoxExit.Location = new System.Drawing.Point(1003, 9);
            this.pictureBoxExit.Name = "pictureBoxExit";
            this.pictureBoxExit.Size = new System.Drawing.Size(35, 35);
            this.pictureBoxExit.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxExit.TabIndex = 1;
            this.pictureBoxExit.TabStop = false;
            this.pictureBoxExit.Click += new System.EventHandler(this.pictureBoxExit_Click);
            // 
            // pictureSize
            // 
            this.pictureSize.Cursor = System.Windows.Forms.Cursors.SizeWE;
            this.pictureSize.Image = ((System.Drawing.Image)(resources.GetObject("pictureSize.Image")));
            this.pictureSize.Location = new System.Drawing.Point(6, 9);
            this.pictureSize.Name = "pictureSize";
            this.pictureSize.Size = new System.Drawing.Size(35, 35);
            this.pictureSize.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureSize.TabIndex = 0;
            this.pictureSize.TabStop = false;
            this.pictureSize.Click += new System.EventHandler(this.pictureSize_Click);
            // 
            // panelConten
            // 
            this.panelConten.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelConten.Location = new System.Drawing.Point(250, 50);
            this.panelConten.Name = "panelConten";
            this.panelConten.Size = new System.Drawing.Size(1050, 600);
            this.panelConten.TabIndex = 2;
            this.panelConten.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panelConten_MouseDown);
            // 
            // MainQL
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1300, 650);
            this.Controls.Add(this.panelConten);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panelMenu);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "MainQL";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Main";
            this.panelMenu.ResumeLayout(false);
            this.panelMenu.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxExit)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureSize)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelMenu;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureSize;
        private System.Windows.Forms.Button buttonNV;
        private System.Windows.Forms.Button buttonLuong;
        private System.Windows.Forms.PictureBox pictureBoxExit;
        private System.Windows.Forms.Button buttonHome;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button buttonCorona;
        private System.Windows.Forms.Button buttonTaiChinh;
        private System.Windows.Forms.Panel panelConten;
        private System.Windows.Forms.PictureBox pictureBox2;
    }
}

