﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KTPM_APP
{
    class tblDangNhap
    {
        public string TaiKhoan { set; get; }
        public string MatKhau { set; get; }
        public string Quyen { set; get; }
        public int Id { set; get; }
    }
}
